------------------------------------------
SICE - v0.03
------------------------------------------


------------
AUTORES
------------

Daniel Antonio - danielfranco.dfx@gmail.com
Pablo Menezes  - menezes.pmm@gmail.com
Fabio Gomes    - gomesrocha@gmail.com


---------------
1. Introducao
---------------

Este documento descreve o processo de instalacao da estrutura de comunicacao SICE,
software sujeito e observador.


-------------------------------
2. Instalacao
-------------------------------

Para começar utilizar o SICE basta possuir uma JVM (>= 1.7), descompactar o conteudo 
do arquivo .zip em um local qualquer e configurar os arquivos de configurações 
localizados dentro de cada pasta (sujeito/observador) de acordo com o software utilizado.

Os softwares Observador e Sujeito sao independentes e precisao ser configurados e executados 
separadamente. 

-------------------------------
3. Configuracao
-------------------------------
Antes de executar editar os arquivos de configuracoes. Lembrar add no arquivo listaObservadores.txt 
os hosts que vao receber as mensagens de determinado sujeito. Cada IP deve ficar em uma linha separada.
ex:
127.0.0.1
192.168.0.1

Outra configuracao importante para o sujeito, o ip de origem que ele colocara nas mensagens.


-------------------------------
4. Execucao
-------------------------------

Para executar, entrar na pasta do observador ou do sujeito e executar o jar da seguinte maneira:

java -jar siceSujeito.jar
e/ou
java -jar siceObservador.jar

-------------------------------
4. Plugins
-------------------------------

Na pasta plugins tem um exemplo de um plugin feito em java script, usando o netcat. Só a titulo de 
exemplo.

