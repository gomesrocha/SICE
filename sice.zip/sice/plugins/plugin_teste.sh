# Esse script simula um plugin de monitoracao para a estrutura SICE. O desenvolvedor
# do plugin cria a sua lógica e seus parametros de monitoracao, assim que identificar 
# uma situacao de alerta, basta enviar uma string com o nome do plugin e o nivel de alerta
# "PLUGIN A - 3" para a porta que o programa sujeito estiver rodando. No exemplo abaixo
# foi enviado uma string utilizando o netcat na porta 3606.


echo "PLUGIN A - 3" | nc 127.0.0.7 3606
